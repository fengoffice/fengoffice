<?php return array(
	'_language_name' => '简体中文',
	'_ext_language_file' => 'ext-lang-zh_CN.js',
); ?>
