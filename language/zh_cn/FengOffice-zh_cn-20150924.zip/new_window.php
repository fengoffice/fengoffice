<?php

	/*
	* Els� magyar ford�t�s 1.4.2 verzi�ig: Luk�cs P�ter <programozo@lukacspeter.hu>
	*/
return array(
	'open in new window' => '在新窗口中打开'
);
?>