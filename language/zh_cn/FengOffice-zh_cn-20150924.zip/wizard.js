locale = 'zh_cn';
addLangs({
	'workspace x': '工作区{0}'
});
